package com.example.CRUD.Exercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
